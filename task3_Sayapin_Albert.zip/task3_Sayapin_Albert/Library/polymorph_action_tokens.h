#include <cstdio>
#include "Action.h"

/**
 * This function allows you to make any actions on tokens if you
 * developed essential interface;
 * It supposes file to opened and pointed on by fd pointer;
 */ 
void
polymorph_action_tokens(FILE *fd, Action &action);
